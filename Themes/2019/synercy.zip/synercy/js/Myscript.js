$(function () {
    $('.main-content').isotope({
        // options
        itemSelector: '.main-item'
       
      });
      $(".box").snakeify();
      $(".box").snakeify({
        
          speed: 2000
        
        });
        

});